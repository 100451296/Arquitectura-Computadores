#!/bin/bash

g++ leertraza.cpp -o leerTraza
sudo cp leerTraza /usr/local/bin/