#!/bin/bash

g++ leer.cpp -o leer
sudo cp leer /usr/local/bin/