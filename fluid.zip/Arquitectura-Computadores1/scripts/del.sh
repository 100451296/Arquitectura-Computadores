#!/bin/sh

find ~/proyecto -mindepth 1 ! -name 'CMakeLists.txt' -exec rm -rf {} \;